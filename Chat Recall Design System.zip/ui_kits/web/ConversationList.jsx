// Chat Recall — Middle column: filter bar + conversation list
function ConversationList({ results, selected, onSelect, sort, setSort }) {
  return React.createElement('section', {
    style: {
      flex: `0 0 var(--cr-convos-w)`,
      borderRight: '1px solid var(--cr-line-1)',
      background: 'var(--cr-ink-0)',
      display: 'flex', flexDirection: 'column', overflow: 'hidden',
    },
  },
    // Subheader
    React.createElement('div', {
      style: {
        height: 'var(--cr-subbar-h)', flexShrink: 0,
        padding: '0 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        borderBottom: '1px solid var(--cr-line-1)',
      },
    },
      React.createElement('div', { style: { display: 'flex', alignItems: 'baseline', gap: 8 } },
        React.createElement('h3', { style: { fontSize: 14, fontWeight: 600 } }, 'Conversations'),
        React.createElement('span', {
          style: { fontSize: 12, color: 'var(--cr-fg-3)', fontVariantNumeric: 'tabular-nums' },
        }, results.length),
      ),
      React.createElement(SegmentedControl, {
        size: 'sm',
        options: [
          { value: 'recent', label: 'Recent' },
          { value: 'cost',   label: 'Cost' },
          { value: 'rel',    label: 'Relevance' },
        ],
        value: sort, onChange: setSort,
      }),
    ),

    // Results list
    React.createElement('div', { style: { flex: 1, overflowY: 'auto' } },
      results.map((r, i) => React.createElement(ResultRow, {
        key: r.id, r, on: selected === r.id, onClick: () => onSelect(r.id),
        showDateDivider: i === 0 || r.dateGroup !== results[i - 1].dateGroup,
      })),
      results.length === 0 && React.createElement('div', {
        style: { padding: 48, textAlign: 'center', color: 'var(--cr-fg-3)' },
      },
        React.createElement(Icon, { name: 'search', size: 22, style: { opacity: 0.4, marginBottom: 12 } }),
        React.createElement('div', { style: { fontSize: 13 } }, 'No matching conversations'),
      ),
    ),
  );
}

function ResultRow({ r, on, onClick, showDateDivider }) {
  const [hov, setHov] = React.useState(false);
  return React.createElement(React.Fragment, null,
    showDateDivider && React.createElement('div', {
      style: {
        padding: '14px 16px 6px',
        fontSize: 11, fontWeight: 500, letterSpacing: '0.04em', textTransform: 'uppercase',
        color: 'var(--cr-fg-3)',
      },
    }, r.dateGroup),

    React.createElement('div', {
      onClick,
      onMouseEnter: () => setHov(true), onMouseLeave: () => setHov(false),
      style: {
        padding: '12px 16px',
        cursor: 'pointer',
        position: 'relative',
        background: on ? 'var(--cr-ink-2)' : hov ? 'var(--cr-ink-1)' : 'transparent',
        transition: 'background var(--cr-dur-fast)',
      },
    },
      // Selected indicator (left accent line)
      on && React.createElement('div', {
        style: {
          position: 'absolute', left: 0, top: 14, bottom: 14,
          width: 2, borderRadius: '0 2px 2px 0',
          background: 'var(--cr-brand-500)',
        },
      }),

      // Top line: tool + project + time
      React.createElement('div', {
        style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 },
      },
        React.createElement(ToolBadge, { tool: r.tool, size: 'sm' }),
        React.createElement('span', {
          style: {
            flex: 1, fontSize: 12, fontWeight: 500, color: 'var(--cr-fg-2)',
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          },
        }, r.project),
        React.createElement('span', { style: { fontSize: 11, color: 'var(--cr-fg-3)' } }, r.time),
      ),

      // Title
      React.createElement('div', {
        style: {
          fontSize: 14, fontWeight: 500, color: 'var(--cr-fg-1)',
          marginBottom: 4, letterSpacing: '-0.005em',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        },
      }, r.title),

      // Preview
      React.createElement('div', {
        style: {
          fontSize: 13, color: 'var(--cr-fg-2)', lineHeight: 1.45,
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden',
          marginBottom: 8,
        },
      }, r.preview),

      // Meta row
      React.createElement('div', {
        style: {
          display: 'flex', alignItems: 'center', gap: 10,
          fontSize: 11, color: 'var(--cr-fg-3)', fontVariantNumeric: 'tabular-nums',
        },
      },
        React.createElement('span', { style: { display: 'inline-flex', alignItems: 'center', gap: 4 } },
          React.createElement(Icon, { name: 'message', size: 11 }), r.turns, ' turns',
        ),
        React.createElement('span', null, '·'),
        React.createElement('span', {
          style: { fontFamily: 'var(--cr-font-mono)', color: 'var(--cr-warn-500)' },
        }, r.cost),
        r.savings && [React.createElement('span', { key: 'd' }, '·'),
          React.createElement('span', { key: 's', style: { color: 'var(--cr-ok-500)' } }, r.savings, ' cached'),
        ],
      ),
    ),
  );
}

window.ConversationList = ConversationList;
