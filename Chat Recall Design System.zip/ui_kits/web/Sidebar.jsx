// Chat Recall — Left Sidebar (projects + filters)
function Sidebar({ projects, selected, onSelect, toolFilter, setToolFilter }) {
  return React.createElement('aside', {
    style: {
      flex: `0 0 var(--cr-sidebar-w)`,
      background: 'var(--cr-ink-1)',
      borderRight: '1px solid var(--cr-line-1)',
      display: 'flex', flexDirection: 'column',
      overflow: 'hidden',
    },
  },
    // Section: Filter by tool
    React.createElement('div', { style: { padding: '16px 12px 10px' } },
      React.createElement('div', { className: 'cr-h4', style: { marginBottom: 10, paddingLeft: 6 } }, 'Source'),
      React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 1 } },
        [
          { id: 'all',      label: 'All sources', icon: 'database', count: 506, color: 'var(--cr-fg-2)' },
          { id: 'claude',   label: 'Claude Code', icon: null, count: 350, color: 'var(--cr-tool-claude)' },
          { id: 'gemini',   label: 'Gemini CLI',  icon: null, count: 98,  color: 'var(--cr-tool-gemini)' },
          { id: 'opencode', label: 'OpenCode',    icon: null, count: 58,  color: 'var(--cr-tool-opencode)' },
        ].map(t => {
          const on = toolFilter === t.id;
          return React.createElement(SidebarRow, {
            key: t.id, on, onClick: () => setToolFilter(t.id),
            left: t.icon
              ? React.createElement(Icon, { name: t.icon, size: 14, style: { color: on ? 'var(--cr-brand-500)' : 'var(--cr-fg-3)' } })
              : React.createElement('span', {
                  style: { width: 8, height: 8, borderRadius: '50%', background: t.color, flexShrink: 0 },
                }),
            label: t.label, count: t.count,
          });
        }),
      ),
    ),

    // Divider
    React.createElement('div', { style: { height: 1, background: 'var(--cr-line-1)', margin: '6px 12px' } }),

    // Section: Projects
    React.createElement('div', {
      style: { padding: '10px 12px 4px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' },
    },
      React.createElement('div', { className: 'cr-h4', style: { paddingLeft: 6 } }, 'Projects'),
      React.createElement(IconButton, { icon: 'filter', size: 22 }),
    ),

    React.createElement('div', {
      style: { flex: 1, overflowY: 'auto', padding: '4px 12px 16px', display: 'flex', flexDirection: 'column', gap: 1 },
    },
      projects.map(p => {
        const on = selected === p.id;
        return React.createElement(SidebarRow, {
          key: p.id, on, onClick: () => onSelect(p.id),
          left: React.createElement(Avatar, { name: p.name, size: 20 }),
          label: p.name, count: p.count,
          highlight: p.starred,
        });
      })
    ),
  );
}

function SidebarRow({ on, onClick, left, label, count, highlight }) {
  const [hov, setHov] = React.useState(false);
  return React.createElement('div', {
    onClick, onMouseEnter: () => setHov(true), onMouseLeave: () => setHov(false),
    style: {
      display: 'flex', alignItems: 'center', gap: 8,
      padding: '6px 8px', height: 32,
      borderRadius: 6, cursor: 'pointer',
      background: on ? 'var(--cr-ink-3)' : hov ? 'var(--cr-ink-2)' : 'transparent',
      color: on ? 'var(--cr-fg-1)' : 'var(--cr-fg-2)',
      transition: 'background var(--cr-dur-fast), color var(--cr-dur-fast)',
    },
  },
    left,
    React.createElement('span', {
      style: {
        flex: 1, fontSize: 13, fontWeight: on ? 500 : 400,
        letterSpacing: '-0.005em',
        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
        color: on ? 'var(--cr-fg-1)' : 'inherit',
      },
    }, label),
    count != null && React.createElement('span', {
      style: {
        fontSize: 11, color: 'var(--cr-fg-3)',
        fontVariantNumeric: 'tabular-nums',
      },
    }, count),
  );
}

window.Sidebar = Sidebar;
