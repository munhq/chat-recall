// Chat Recall — Memory Explorer (v2 premium)
function MemoryExplorer({ tab, setTab, items, selected, onSelect }) {
  const tabs = [
    { id: 'all',       label: 'All',        count: 1127 },
    { id: 'sessions',  label: 'Sessions',   count: 490 },
    { id: 'plans',     label: 'Plans',      count: 54 },
    { id: 'tasks',     label: 'Tasks',      count: 62 },
    { id: 'claude_md', label: 'CLAUDE.md',  count: 9 },
    { id: 'history',   label: 'History',    count: 71 },
    { id: 'paste',     label: 'Pastes',     count: 441 },
  ];
  const detail = items.find(i => i.id === selected);

  return React.createElement('div', {
    style: { flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--cr-ink-0)', overflow: 'hidden' },
  },
    // Header
    React.createElement('div', {
      style: {
        padding: '24px 32px 16px',
        borderBottom: '1px solid var(--cr-line-1)',
      },
    },
      React.createElement('div', { style: { display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 18 } },
        React.createElement('div', null,
          React.createElement('h2', null, 'Memory'),
          React.createElement('p', { className: 'cr-lead', style: { marginTop: 4 } },
            'Everything your tools remember — searchable, linked, and yours.'),
        ),
        React.createElement('div', { style: { display: 'flex', gap: 8 } },
          React.createElement(Button, { variant: 'outline', size: 'md', icon: 'arrowUp' }, 'Export'),
          React.createElement(Button, { variant: 'primary', size: 'md', icon: 'plus' }, 'New note'),
        ),
      ),
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 12 } },
        React.createElement(Input, {
          value: '', onChange: () => {},
          placeholder: 'Search across all memory types…',
          kbd: '/',
          style: { maxWidth: 480 },
        }),
        React.createElement(Button, { variant: 'outline', size: 'md', icon: 'filter' }, 'Filter'),
      ),
    ),

    // Tabs
    React.createElement('div', {
      style: { padding: '12px 32px', borderBottom: '1px solid var(--cr-line-1)', display: 'flex', gap: 4, flexWrap: 'wrap' },
    },
      tabs.map(t => {
        const on = t.id === tab;
        return React.createElement('button', {
          key: t.id, onClick: () => setTab(t.id),
          style: {
            height: 30, padding: '0 12px',
            display: 'inline-flex', alignItems: 'center', gap: 7,
            background: on ? 'var(--cr-ink-3)' : 'transparent',
            color: on ? 'var(--cr-fg-1)' : 'var(--cr-fg-2)',
            border: on ? '1px solid var(--cr-line-2)' : '1px solid transparent',
            borderRadius: 6, cursor: 'pointer',
            fontFamily: 'inherit', fontSize: 13, fontWeight: on ? 500 : 400,
            transition: 'all var(--cr-dur-fast)',
          },
        }, t.label,
          React.createElement('span', {
            style: {
              fontSize: 11, color: 'var(--cr-fg-3)',
              padding: '1px 6px', background: 'var(--cr-ink-2)',
              borderRadius: 4, fontVariantNumeric: 'tabular-nums',
            },
          }, t.count),
        );
      }),
    ),

    // Body: list + detail
    React.createElement('div', { style: { flex: 1, display: 'flex', overflow: 'hidden' } },
      // list
      React.createElement('div', {
        style: {
          flex: '0 0 440px', borderRight: '1px solid var(--cr-line-1)', overflowY: 'auto', padding: '12px 16px 32px',
          display: 'flex', flexDirection: 'column', gap: 8,
        },
      },
        items.map(it => React.createElement(MemoryRow, {
          key: it.id, it, on: it.id === selected, onClick: () => onSelect(it.id),
        })),
      ),
      // detail
      React.createElement('div', { style: { flex: 1, overflowY: 'auto', padding: '28px 40px' } },
        detail ? React.createElement(MemoryDetail, { item: detail })
          : React.createElement('div', { style: { color: 'var(--cr-fg-3)', fontSize: 14, textAlign: 'center', paddingTop: 80 } },
              'Select an item to preview'),
      ),
    ),
  );
}

function MemoryRow({ it, on, onClick }) {
  const [hov, setHov] = React.useState(false);
  return React.createElement('div', {
    onClick, onMouseEnter: () => setHov(true), onMouseLeave: () => setHov(false),
    style: {
      padding: 14,
      background: on ? 'var(--cr-ink-2)' : hov ? 'var(--cr-ink-1)' : 'transparent',
      border: '1px solid ' + (on ? 'var(--cr-line-2)' : 'var(--cr-line-1)'),
      borderRadius: 'var(--cr-radius-md)',
      cursor: 'pointer',
      transition: 'background var(--cr-dur-fast), border-color var(--cr-dur-fast)',
    },
  },
    React.createElement('div', {
      style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
    },
      React.createElement(SourceBadge, { source: it.source, size: 'sm' }),
      it.score && React.createElement('span', {
        style: {
          fontSize: 11, color: 'var(--cr-brand-500)',
          fontFamily: 'var(--cr-font-mono)', fontVariantNumeric: 'tabular-nums',
        },
      }, it.score),
    ),
    React.createElement('div', {
      style: { fontSize: 14, fontWeight: 500, color: 'var(--cr-fg-1)', marginBottom: 4, letterSpacing: '-0.005em' },
    }, it.title),
    React.createElement('div', {
      style: { fontSize: 13, color: 'var(--cr-fg-2)', lineHeight: 1.45,
               display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', marginBottom: 6 },
    }, it.preview),
    React.createElement('div', {
      style: { fontSize: 11, color: 'var(--cr-fg-3)', fontFamily: 'var(--cr-font-mono)' },
    }, it.path),
  );
}

function MemoryDetail({ item }) {
  return React.createElement('div', { style: { maxWidth: 680 } },
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 } },
      React.createElement(SourceBadge, { source: item.source }),
      React.createElement('span', { style: { fontSize: 12, color: 'var(--cr-fg-3)' } }, item.project),
    ),
    React.createElement('h2', { style: { marginBottom: 16 } }, item.title),
    React.createElement('div', {
      style: { display: 'flex', gap: 24, padding: '12px 0', borderTop: '1px solid var(--cr-line-1)', borderBottom: '1px solid var(--cr-line-1)', marginBottom: 20, fontSize: 12 },
    },
      React.createElement('div', null,
        React.createElement('div', { style: { color: 'var(--cr-fg-3)', marginBottom: 2 } }, 'Path'),
        React.createElement('code', null, item.path),
      ),
      React.createElement('div', null,
        React.createElement('div', { style: { color: 'var(--cr-fg-3)', marginBottom: 2 } }, 'Modified'),
        React.createElement('div', { style: { color: 'var(--cr-fg-1)' } }, item.mtime),
      ),
    ),
    React.createElement('pre', {
      style: { fontSize: 13, whiteSpace: 'pre-wrap', lineHeight: 1.6 },
    }, item.body),
  );
}

window.MemoryExplorer = MemoryExplorer;
