// Chat Recall — Insights / Dashboard
function Dashboard() {
  const costSeries = [0.2, 0.4, 0.3, 0.8, 1.1, 0.6, 0.5, 1.5, 2.1, 0.8, 0.3, 1.2, 1.7, 2.4, 1.9, 0.9, 0.4, 1.3, 2.6, 3.1, 2.7, 1.8, 1.1, 2.2, 2.9, 3.5, 2.1, 1.4, 0.9, 1.6];
  const maxC = Math.max(...costSeries);

  const toolBars = [
    { name: 'Bash',  value: 1284, pct: 100, color: 'var(--cr-brand-500)' },
    { name: 'Read',  value: 1095, pct: 85,  color: 'var(--cr-brand-500)' },
    { name: 'Edit',  value: 881,  pct: 69,  color: 'var(--cr-brand-500)' },
    { name: 'Write', value: 488,  pct: 38,  color: 'var(--cr-info-500)' },
    { name: 'Agent', value: 182,  pct: 14,  color: 'var(--cr-tool-opencode)' },
  ];

  const projects = [
    { name: 'personal/chat-recall', cost: '$4.12', sessions: 162, langs: ['TS', 'CSS'] },
    { name: 'personal/munbot',      cost: '$3.48', sessions: 95,  langs: ['Rust'] },
    { name: 'personal/k8s_gpu',     cost: '$1.91', sessions: 111, langs: ['Go', 'YAML'] },
    { name: 'personal/poly',        cost: '$1.57', sessions: 162, langs: ['Python'] },
  ];

  return React.createElement('div', {
    style: { flex: 1, overflowY: 'auto', background: 'var(--cr-ink-0)' },
  },
    React.createElement('div', { style: { maxWidth: 1280, margin: '0 auto', padding: '32px 40px 64px' } },
      // Header
      React.createElement('div', { style: { display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 32 } },
        React.createElement('div', null,
          React.createElement('h2', null, 'Insights'),
          React.createElement('p', { className: 'cr-lead', style: { marginTop: 4 } },
            'Where your tokens go — and what you can cut.'),
        ),
        React.createElement('div', { style: { display: 'flex', gap: 8 } },
          React.createElement(SegmentedControl, {
            options: [
              { value: '7d', label: '7d' }, { value: '30d', label: '30d' }, { value: 'all', label: 'All time' },
            ],
            value: '30d', onChange: () => {},
          }),
          React.createElement(IconButton, { icon: 'refresh' }),
        ),
      ),

      // This-week digest card
      React.createElement('div', {
        style: {
          background: 'var(--cr-ink-1)',
          border: '1px solid var(--cr-line-1)',
          borderRadius: 'var(--cr-radius-lg)',
          padding: 28, marginBottom: 24,
          position: 'relative', overflow: 'hidden',
        },
      },
        // subtle brand glow
        React.createElement('div', {
          style: {
            position: 'absolute', top: -80, right: -80, width: 260, height: 260,
            background: 'radial-gradient(circle, rgba(245,169,127,0.12) 0%, transparent 60%)',
            pointerEvents: 'none',
          },
        }),
        React.createElement('div', { style: { position: 'relative' } },
          React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 } },
            React.createElement('h3', null, 'This week'),
            React.createElement(Chip, { kind: 'ok', icon: 'arrowDown' }, '12% vs last week'),
          ),
          React.createElement('div', {
            style: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 32, marginBottom: 20 },
          },
            [
              { v: '53',    l: 'Sessions',     tone: 'neutral' },
              { v: '$5.41', l: 'Cost',         tone: 'cost' },
              { v: '58%',   l: 'Cache hit',    tone: 'savings' },
              { v: '412K',  l: 'Tokens used',  tone: 'neutral' },
            ].map(s => React.createElement('div', { key: s.l },
              React.createElement('div', {
                style: {
                  fontSize: 32, fontWeight: 600, letterSpacing: '-0.025em',
                  color: s.tone === 'cost' ? 'var(--cr-warn-500)' : s.tone === 'savings' ? 'var(--cr-ok-500)' : 'var(--cr-fg-1)',
                  fontVariantNumeric: 'tabular-nums',
                },
              }, s.v),
              React.createElement('div', { style: { fontSize: 12, color: 'var(--cr-fg-3)', marginTop: 2, fontWeight: 500 } }, s.l),
            )),
          ),
          React.createElement('div', {
            style: {
              padding: '12px 14px', borderRadius: 'var(--cr-radius-sm)',
              background: 'var(--cr-warn-surf)',
              border: '1px solid var(--cr-warn-line)',
              display: 'flex', alignItems: 'center', gap: 10, fontSize: 13,
            },
          },
            React.createElement(Icon, { name: 'sparkle', size: 14, style: { color: 'var(--cr-warn-500)' } }),
            React.createElement('span', { style: { color: 'var(--cr-fg-1)' } },
              React.createElement('strong', { style: { fontWeight: 600 } }, 'personal/munbot'),
              ' peaked Wed with 13 hours of context — 2× your weekly average.'),
            React.createElement('a', { href: '#', style: { marginLeft: 'auto' } }, 'Review →'),
          ),
        ),
      ),

      // Lifetime metric grid
      React.createElement('div', {
        style: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 },
      },
        React.createElement(MetricCard, { label: 'Total sessions', value: '814', sub: '+ 53 this week', icon: 'message' }),
        React.createElement(MetricCard, { label: 'Total cost', value: '$13.99', sub: 'Lifetime', tone: 'cost', icon: 'sparkle' }),
        React.createElement(MetricCard, { label: 'Compute time', value: '74d 12h', sub: 'Across 12 projects', icon: 'clock' }),
        React.createElement(MetricCard, { label: 'Cache savings', value: '82.7B tokens', sub: 'At list: ≈ $248', tone: 'savings', icon: 'zap' }),
      ),

      // Cost chart
      React.createElement(Card, { style: { padding: 24, marginBottom: 24 } },
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 } },
          React.createElement('h3', null, 'Daily cost'),
          React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 14, fontSize: 12, color: 'var(--cr-fg-3)' } },
            React.createElement(LegendDot, { color: 'var(--cr-brand-500)', label: 'Normal' }),
            React.createElement(LegendDot, { color: 'var(--cr-warn-500)', label: 'Spike' }),
          ),
        ),
        React.createElement('div', {
          style: { display: 'flex', alignItems: 'flex-end', gap: 3, height: 160, padding: '8px 0' },
        },
          costSeries.map((v, i) => React.createElement('div', {
            key: i,
            title: `$${v.toFixed(2)}`,
            style: {
              flex: 1,
              height: `${(v / maxC) * 100}%`,
              background: v > 3 ? 'var(--cr-warn-500)' : 'var(--cr-brand-500)',
              opacity: v > 3 ? 0.95 : 0.75,
              borderRadius: '3px 3px 0 0', minHeight: 2,
              transition: 'opacity var(--cr-dur-fast)',
            },
          })),
        ),
        React.createElement('div', {
          style: { display: 'flex', justifyContent: 'space-between', marginTop: 10, fontSize: 11, color: 'var(--cr-fg-3)' },
        },
          React.createElement('span', null, '30 days ago'),
          React.createElement('span', null, 'Today'),
        ),
      ),

      // Two-column: tools + projects
      React.createElement('div', {
        style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 },
      },
        React.createElement(Card, { style: { padding: 24 } },
          React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 } },
            React.createElement('h3', null, 'Top tools'),
            React.createElement('a', { href: '#', style: { fontSize: 12 } }, 'See all'),
          ),
          React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 10 } },
            toolBars.map(b => React.createElement('div', { key: b.name, style: { display: 'flex', alignItems: 'center', gap: 12 } },
              React.createElement('span', {
                style: { fontSize: 13, color: 'var(--cr-fg-1)', fontWeight: 500, minWidth: 70 },
              }, b.name),
              React.createElement('div', {
                style: { flex: 1, height: 8, background: 'var(--cr-ink-2)', borderRadius: 4, overflow: 'hidden' },
              },
                React.createElement('div', {
                  style: { height: '100%', width: `${b.pct}%`, background: b.color, borderRadius: 4 },
                }),
              ),
              React.createElement('span', {
                style: { fontSize: 12, color: 'var(--cr-fg-3)', minWidth: 50, textAlign: 'right',
                         fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--cr-font-mono)' },
              }, b.value.toLocaleString()),
            )),
          ),
        ),

        React.createElement(Card, { style: { padding: 24 } },
          React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 } },
            React.createElement('h3', null, 'Top projects'),
            React.createElement('a', { href: '#', style: { fontSize: 12 } }, 'See all'),
          ),
          React.createElement('div', { style: { display: 'flex', flexDirection: 'column' } },
            projects.map((p, i) => React.createElement('div', {
              key: p.name,
              style: {
                display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0',
                borderBottom: i < projects.length - 1 ? '1px solid var(--cr-line-1)' : 'none',
              },
            },
              React.createElement(Avatar, { name: p.name, size: 30 }),
              React.createElement('div', { style: { flex: 1, minWidth: 0 } },
                React.createElement('div', {
                  style: { fontSize: 13, fontWeight: 500, color: 'var(--cr-fg-1)', letterSpacing: '-0.005em' },
                }, p.name),
                React.createElement('div', { style: { fontSize: 11, color: 'var(--cr-fg-3)', marginTop: 2 } },
                  p.sessions, ' sessions · ', p.langs.join(' · ')),
              ),
              React.createElement('span', {
                style: { fontSize: 14, fontWeight: 600, color: 'var(--cr-warn-500)',
                         fontVariantNumeric: 'tabular-nums', fontFamily: 'var(--cr-font-mono)' },
              }, p.cost),
            )),
          ),
        ),
      ),
    ),
  );
}

function LegendDot({ color, label }) {
  return React.createElement('span', { style: { display: 'inline-flex', alignItems: 'center', gap: 6 } },
    React.createElement('span', { style: { width: 8, height: 8, borderRadius: 2, background: color } }),
    label,
  );
}

window.Dashboard = Dashboard;
