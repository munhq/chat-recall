// Chat Recall — Right pane: full conversation viewer
function ConversationViewer({ conversation }) {
  if (!conversation) {
    return React.createElement('div', {
      style: {
        flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--cr-ink-0)', color: 'var(--cr-fg-3)',
      },
    },
      React.createElement('div', { style: { textAlign: 'center' } },
        React.createElement(Icon, { name: 'message', size: 28, style: { opacity: 0.3, marginBottom: 14 } }),
        React.createElement('div', { style: { fontSize: 14 } }, 'Select a conversation to view it'),
      ),
    );
  }
  const c = conversation;

  return React.createElement('div', {
    style: {
      flex: 1, overflowY: 'auto', background: 'var(--cr-ink-0)',
      display: 'flex', justifyContent: 'center',
    },
  },
    React.createElement('div', {
      style: { width: '100%', maxWidth: 820, padding: '32px 32px 80px' },
    },
      // Title + CTAs
      React.createElement('div', {
        style: { display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 10, flexWrap: 'wrap' },
      },
        React.createElement('div', { style: { flex: 1, minWidth: 0 } },
          React.createElement('div', {
            style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 },
          },
            React.createElement(ToolBadge, { tool: c.tool }),
            React.createElement('span', { style: { fontSize: 13, fontWeight: 500, color: 'var(--cr-fg-2)' } }, c.project),
            React.createElement('span', { style: { fontSize: 13, color: 'var(--cr-fg-3)' } }, '·'),
            React.createElement('span', { style: { fontSize: 13, color: 'var(--cr-fg-3)' } }, c.date),
          ),
          React.createElement('h1', {
            style: { fontSize: 24, fontWeight: 600, letterSpacing: '-0.015em', color: 'var(--cr-fg-1)' },
          }, c.title),
        ),
        React.createElement('div', { style: { display: 'flex', gap: 8 } },
          React.createElement(Button, { variant: 'outline', size: 'md', icon: 'arrowUp' }, 'Export'),
          React.createElement(Button, { variant: 'primary', size: 'md', icon: 'arrowRight' }, 'Resume session'),
        ),
      ),

      // Meta row
      React.createElement('div', {
        style: { display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 20 },
      },
        React.createElement(Chip, { kind: 'mono', icon: 'tag' }, c.slug),
        React.createElement(Chip, { kind: 'ok', icon: 'check' }, c.branch),
        React.createElement(Chip, { kind: 'warn' }, c.cost),
        React.createElement(Chip, { kind: 'ok' }, 'saved ', c.savings),
        c.tools.map(t => React.createElement(Chip, { key: t, kind: 'mono' }, t)),
      ),

      // Token strip (inline)
      React.createElement('div', {
        style: {
          display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 1,
          background: 'var(--cr-line-1)',
          border: '1px solid var(--cr-line-1)',
          borderRadius: 'var(--cr-radius-md)',
          marginBottom: 32,
          overflow: 'hidden',
        },
      },
        [
          ['Input',  c.tokens.in],
          ['Output', c.tokens.out],
          ['Cache read', c.tokens.cacheR],
          ['Cache write', c.tokens.cacheW],
          ['Peak ctx', c.tokens.peak],
        ].map(([l, v]) => React.createElement('div', {
          key: l,
          style: {
            padding: '12px 16px', background: 'var(--cr-ink-1)',
            display: 'flex', flexDirection: 'column', gap: 3,
          },
        },
          React.createElement('div', { style: { fontSize: 11, color: 'var(--cr-fg-3)', fontWeight: 500, letterSpacing: '0.02em', textTransform: 'uppercase' } }, l),
          React.createElement('div', { style: { fontSize: 15, fontWeight: 600, color: 'var(--cr-fg-1)', fontVariantNumeric: 'tabular-nums' } }, v),
        )),
      ),

      // Messages
      c.messages.map((m, i) => React.createElement(Message, { key: i, m })),
    ),
  );
}

function Message({ m }) {
  return React.createElement('div', {
    style: { marginBottom: 24, display: 'flex', gap: 14 },
  },
    React.createElement('div', {
      style: {
        width: 28, height: 28, flexShrink: 0,
        borderRadius: 6,
        background: m.role === 'user' ? 'var(--cr-ink-2)' : 'var(--cr-brand-surf)',
        border: '1px solid ' + (m.role === 'user' ? 'var(--cr-line-1)' : 'var(--cr-brand-line)'),
        color: m.role === 'user' ? 'var(--cr-fg-2)' : 'var(--cr-brand-500)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 11, fontWeight: 600, letterSpacing: '0.04em', textTransform: 'uppercase',
      },
    }, m.role === 'user' ? 'You' : 'AI'),
    React.createElement('div', { style: { flex: 1, minWidth: 0, paddingTop: 3 } },
      React.createElement('div', {
        style: { fontSize: 14, color: 'var(--cr-fg-1)', lineHeight: 1.6, whiteSpace: 'pre-wrap' },
      }, m.text),
      m.code && React.createElement('pre', { style: { marginTop: 12 } },
        React.createElement('code', null, m.code)
      ),
    ),
  );
}

window.ConversationViewer = ConversationViewer;
