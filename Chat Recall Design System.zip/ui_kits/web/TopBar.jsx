// Chat Recall — App shell: TopBar with logo, global search, nav, user
function TopBar({ view, setView, query, setQuery }) {
  const [theme, setTheme] = React.useState(
    () => document.documentElement.getAttribute('data-theme') || 'dark'
  );
  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark';
    // Suppress transitions during theme swap so CSS-var-driven colors repaint cleanly
    const killer = document.createElement('style');
    killer.textContent = '*,*::before,*::after{transition:none !important;animation:none !important}';
    document.head.appendChild(killer);
    setTheme(next);
    if (next === 'light') document.documentElement.setAttribute('data-theme', 'light');
    else document.documentElement.removeAttribute('data-theme');
    try { localStorage.setItem('cr-theme', next); } catch (e) {}
    // Force one frame to apply, then drop the killer
    requestAnimationFrame(() => requestAnimationFrame(() => killer.remove()));
  };
  const navItems = [
    { id: 'conversations', label: 'Conversations', icon: 'message' },
    { id: 'memory',        label: 'Memory',        icon: 'brain' },
    { id: 'dashboard',     label: 'Insights',      icon: 'chart' },
  ];
  return React.createElement('header', {
    style: {
      height: 'var(--cr-header-h)', flexShrink: 0,
      background: 'var(--cr-ink-1)',
      borderBottom: '1px solid var(--cr-line-1)',
      display: 'flex', alignItems: 'center',
      padding: '0 16px', gap: 16,
    },
  },
    // Brand
    React.createElement('div', {
      style: { display: 'flex', alignItems: 'center', gap: 10, minWidth: 'var(--cr-sidebar-w)', paddingLeft: 4 },
    },
      React.createElement(Logo, { size: 26 }),
      React.createElement('span', {
        style: { fontSize: 15, fontWeight: 600, letterSpacing: '-0.02em', color: 'var(--cr-fg-1)' },
      }, 'Chat Recall'),
      React.createElement('span', {
        style: {
          padding: '2px 6px', fontSize: 10, fontWeight: 500, letterSpacing: '0.04em',
          color: 'var(--cr-fg-3)', background: 'var(--cr-ink-2)',
          border: '1px solid var(--cr-line-1)', borderRadius: 4, textTransform: 'uppercase',
        },
      }, 'Beta'),
    ),

    // Nav
    React.createElement('nav', { style: { display: 'flex', gap: 2 } },
      navItems.map(n => {
        const on = view === n.id;
        return React.createElement('button', {
          key: n.id, onClick: () => setView(n.id),
          style: {
            height: 32, padding: '0 12px',
            display: 'inline-flex', alignItems: 'center', gap: 7,
            background: on ? 'var(--cr-ink-2)' : 'transparent',
            color: on ? 'var(--cr-fg-1)' : 'var(--cr-fg-2)',
            border: 'none', borderRadius: 6,
            fontFamily: 'inherit', fontSize: 13, fontWeight: on ? 500 : 400,
            cursor: 'pointer', transition: 'background var(--cr-dur-fast), color var(--cr-dur-fast)',
          },
          onMouseEnter: e => { if (!on) e.currentTarget.style.color = 'var(--cr-fg-1)'; },
          onMouseLeave: e => { if (!on) e.currentTarget.style.color = 'var(--cr-fg-2)'; },
        },
          React.createElement(Icon, { name: n.icon, size: 14 }),
          n.label,
        );
      })
    ),

    // Global search — centered, max 480px
    React.createElement('div', { style: { flex: 1, display: 'flex', justifyContent: 'center', maxWidth: 520, margin: '0 auto' } },
      React.createElement(Input, {
        value: query, onChange: e => setQuery(e.target.value),
        placeholder: 'Search conversations, plans, files…',
        onClear: query ? () => setQuery('') : undefined,
        kbd: '⌘K', size: 'md',
        style: { width: '100%' },
      }),
    ),

    // Right: actions + avatar
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 6 } },
      React.createElement(IconButton, { icon: 'refresh', title: 'Refresh index' }),
      React.createElement(IconButton, {
        icon: theme === 'dark' ? 'sun' : 'moon',
        title: theme === 'dark' ? 'Switch to light' : 'Switch to dark',
        onClick: toggleTheme,
      }),
      React.createElement(IconButton, { icon: 'settings', title: 'Settings' }),
      React.createElement('div', {
        style: {
          width: 28, height: 28, marginLeft: 4,
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #F5A97F 0%, #C9734A 100%)',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          color: '#1A0E06', fontSize: 11, fontWeight: 600, letterSpacing: '-0.01em',
          border: '1px solid var(--cr-line-2)',
        },
      }, 'HM'),
    ),
  );
}
window.TopBar = TopBar;
